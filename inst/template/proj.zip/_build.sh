#!/bin/sh

Rscript -e "puBuild::Rmd_bind(titulo = 'Introdução')"
